#ifndef TYPES
#define TYPES

enum class ConversionType
{
  Temperature,
  Distance
};

#endif
